from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base,sessionmaker

BASE_DIR=Path(__file__).resolve().parents[1]
DATABASE_URL=f"sqlite:///{BASE_DIR/'volcanic.db'}"

engine=create_engine(DATABASE_URL,connect_args={"check_same_thread":False})
SessionLocal=sessionmaker(autocommit=False,autoflush=False,bind=engine)
Base=declarative_base()

def get_db():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.close()