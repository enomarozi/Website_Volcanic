from pathlib import Path
from fastapi import APIRouter,Depends,Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from app.database import get_db
from app.dependencies import get_current_user
from app.models.simulation import Simulation

router=APIRouter(prefix="/simulations",tags=["Simulation History"])
templates=Jinja2Templates(directory="app/templates")

@router.get("/history")
def history(request:Request,user=Depends(get_current_user),db:Session=Depends(get_db)):
    if not user: return RedirectResponse("/login",303)
    simulations=db.query(Simulation).filter(Simulation.user_id==user.id).order_by(Simulation.created_at.desc()).all()
    return templates.TemplateResponse("simulations/history.html",{"request":request,"user":user,"simulations":simulations})

@router.post("/{simulation_id}/delete")
def delete_simulation(simulation_id:int,user=Depends(get_current_user),db:Session=Depends(get_db)):
    if not user: return RedirectResponse("/login",303)
    simulation=db.get(Simulation,simulation_id)
    if not simulation or simulation.user_id!=user.id:
        return RedirectResponse("/simulations/history",303)
    db.delete(simulation)
    db.commit()
    return RedirectResponse("/simulations/history",303)