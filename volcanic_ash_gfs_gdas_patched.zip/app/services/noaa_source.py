from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import re
import shutil
import subprocess
import tempfile
import xarray as xr

BASE_DIR=Path(__file__).resolve().parents[2]
DATA_DIR=BASE_DIR/'data'/'meteorology'
SOURCE_CONFIG={
    'GFS': {'label':'NOAA GFS 0.25°','filter':'https://nomads.ncep.noaa.gov/cgi-bin/filter_gfs_0p25.pl','file_prefix':'gfs'},
    'GDAS': {'label':'NOAA GDAS 0.25°','filter':'https://nomads.ncep.noaa.gov/cgi-bin/filter_gdas_0p25.pl','file_prefix':'gdas'},
}
PRESSURE_LEVELS=[1000,975,950,925,900,850,800,750,700,650,600,550,500,450,400,350,300,250,200,150,100,70,50]

def _cycle(dt:datetime):
    dt=dt.astimezone(timezone.utc).replace(minute=0,second=0,microsecond=0)
    hour=(dt.hour//6)*6
    return dt.replace(hour=hour)

def _download(url:str,destination:Path):
    request=Request(url,headers={'User-Agent':'VolcanicAshAnalysis/1.0 contact: local-admin'})
    with urlopen(request,timeout=180) as response, destination.open('wb') as out:
        shutil.copyfileobj(response,out)
    if destination.stat().st_size<10000:
        sample=destination.read_bytes()[:500].decode('utf-8','ignore')
        destination.unlink(missing_ok=True)
        raise RuntimeError(f'NOAA tidak mengembalikan file GRIB yang valid. Respons: {sample[:180]}')

def _query(source:str,cycle:datetime,forecast_hour:int,lat:float,lon:float,kind:str):
    cfg=SOURCE_CONFIG[source]
    file=f"{cfg['file_prefix']}.t{cycle:%H}z.pgrb2.0p25.f{forecast_hour:03d}"
    west=max(-180,lon-15); east=min(180,lon+15); south=max(-90,lat-12); north=min(90,lat+12)
    params={'file':file,'subregion':'','leftlon':f'{west:.2f}','rightlon':f'{east:.2f}','toplat':f'{north:.2f}','bottomlat':f'{south:.2f}'}
    if kind=='upper':
        for level in PRESSURE_LEVELS: params[f'lev_{level}_mb']='on'
        for var in ('HGT','TMP','UGRD','VGRD','VVEL','RH'): params[f'var_{var}']='on'
    elif kind=='instant':
        for lev in ('surface','2_m_above_ground','10_m_above_ground','planetary_boundary_layer','mean_sea_level'):
            params[f'lev_{lev}']='on'
        for var in ('PRES','TMP','UGRD','VGRD','HPBL','LAND','SOILW','TSOIL','DSWRF','USWRF','VGRD','UGRD'):
            params[f'var_{var}']='on'
    else:
        params['lev_surface']='on'
        for var in ('APCP','PRATE'): params[f'var_{var}']='on'
    return cfg['filter']+'?'+urlencode(params)

def _convert(grib:Path,dest:Path,kind:str):
    try:
        import cfgrib  # noqa: F401
    except ImportError as exc:
        raise RuntimeError('Konversi GRIB2 membutuhkan paket cfgrib dan eccodes. Instal dependensi dari requirements.txt.') from exc
    try:
        if kind=='upper':
            ds=xr.open_dataset(grib,engine='cfgrib',backend_kwargs={'filter_by_keys':{'typeOfLevel':'isobaricInhPa'},'indexpath':''})
        elif kind=='accum':
            ds=xr.open_dataset(grib,engine='cfgrib',backend_kwargs={'filter_by_keys':{'typeOfLevel':'surface','stepType':'accum'},'indexpath':''})
        else:
            groups=xr.open_datasets(grib,engine='cfgrib',backend_kwargs={'indexpath':''})
            usable=[]
            for group in groups:
                if any(name in group.data_vars for name in ('t2m','u10','v10','sp','blh','t','u','v','lsm')):
                    usable.append(group)
            if not usable: raise ValueError('Tidak ditemukan grup GRIB surface yang dibutuhkan.')
            ds=xr.merge(usable,compat='override',join='outer')
        rename={}
        for old,new_name in [('isobaricInhPa','pressure_level'),('gh','z'),('2t','t2m'),('10u','u10'),('10v','v10'),('hpbl','blh'),('sp','sp'),('tp','tp'),('prate','prate')]:
            if old in ds.variables or old in ds.dims:
                if old!=new_name: rename[old]=new_name
        if rename: ds=ds.rename(rename)
        if 'valid_time' not in ds.dims:
            if 'valid_time' in ds.coords and ds['valid_time'].ndim==0:
                ds=ds.expand_dims(valid_time=[ds['valid_time'].values])
            elif 'time' in ds.dims:
                ds=ds.rename({'time':'valid_time'})
            else:
                raise ValueError('File GRIB tidak memiliki waktu valid yang dapat dipetakan.')
        ds.to_netcdf(dest)
        ds.close()
    except Exception as exc:
        raise RuntimeError(f'GRIB2 gagal dikonversi ke NetCDF ({grib.name}): {exc}') from exc

def acquire_noaa_dataset(source:str,valid_date:str,forecast_hour:int,latitude:float,longitude:float,uploaded_by:int):
    source=source.upper()
    if source not in SOURCE_CONFIG: raise ValueError('Sumber harus GFS atau GDAS.')
    if not -90<=latitude<=90 or not -180<=longitude<=180: raise ValueError('Koordinat tidak valid.')
    if forecast_hour not in range(0,241,3): raise ValueError('Forecast hour harus 0–240 dengan interval 3 jam.')
    try: dt=datetime.fromisoformat(valid_date.replace('Z','+00:00'))
    except ValueError as exc: raise ValueError('Tanggal harus format ISO, contoh 2026-10-29T00:00:00Z.') from exc
    if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
    cycle=_cycle(dt)
    if source=='GDAS' and forecast_hour>0: raise ValueError('GDAS digunakan untuk analisis; pilih forecast hour 0.')
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    stamp=datetime.utcnow().strftime('%Y%m%d%H%M%S%f')
    paths={}
    with tempfile.TemporaryDirectory(prefix='noaa_') as temp:
        temp=Path(temp)
        for kind in ('upper','instant','accum'):
            grib=temp/f'{kind}.grib2'
            _download(_query(source,cycle,forecast_hour,latitude,longitude,kind),grib)
            dest=DATA_DIR/f'{source.lower()}_{kind}_{stamp}.nc'
            # Each NOAA subset may expose several GRIB message groups; cfgrib needs a group-specific filter.
            try:
                _convert(grib,dest,kind)
            except Exception:
                dest.unlink(missing_ok=True)
                raise
            paths[kind]=str(dest.relative_to(BASE_DIR))
    return {'source':source,'cycle':cycle.isoformat(),'forecast_hour':forecast_hour,'paths':paths,'name':f'{SOURCE_CONFIG[source]["label"]} {cycle:%Y-%m-%d %H}Z f{forecast_hour:03d}','uploaded_by':uploaded_by}
